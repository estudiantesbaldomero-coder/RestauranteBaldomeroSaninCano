Proyecto: Restaurante Escolar - IE Baldomero Sanín Cano
Contenido: Vite + React app (carga CSV, genera QRs, escáner, impresión, dashboard)
Instrucciones rápidas:
1) Instalar dependencias: npm install
2) Ejecutar en desarrollo: npm run dev
3) Compilar: npm run build
4) Para generar APK: seguir README del proyecto original (usar Capacitor)

Nota: Para que el escáner funcione en móvil se necesita HTTPS o localhost.
