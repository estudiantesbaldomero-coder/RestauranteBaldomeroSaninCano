// App.jsx - Restaurante Escolar (single-file main component)
import React, { useEffect, useState, useRef } from 'react';
import Papa from 'papaparse';
import QRCode from 'qrcode.react';

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8);
const STORAGE_KEY = 'restaurante_escolar_v1';

export default function App(){
  const [students, setStudents] = useState([]);
  const [query, setQuery] = useState('');
  const [stats, setStats] = useState({total:0, present:0});
  const [scanning, setScanning] = useState(false);
  const videoRef = useRef(null);
  const qrScannerRef = useRef(null);

  useEffect(()=>{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw) {
      try { const parsed = JSON.parse(raw); setStudents(parsed); }
      catch(e){ console.warn('no se pudo parsear storage', e);}    }
  },[]);

  useEffect(()=>{
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
    const total = students.length;
    const present = students.filter(s=>s.present).length;
    setStats({total, present});
  },[students]);

  const handleCSV = (file) => {
    if(!file) return;
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const rows = results.data.map(row => {
          const name = (row.name || row.nombre || row.NOMBRE || row.Nombre || '').trim();
          const grade = (row.grade || row.grado || row.GRADE || row.Grade || '').trim();
          return {
            id: uid(),
            name: name || 'Sin Nombre',
            grade: grade || 'Sin Grado',
            qrData: '',
            present: false,
          }
        });
        const withQR = rows.map(r=> ({...r, qrData: `IE-BSC|${r.id}|${encodeURIComponent(r.name)}`}));
        setStudents(prev => [...prev, ...withQR]);
      },
      error: (err) => alert('Error al leer CSV: ' + err.message)
    })
  }

  const addStudent = (name, grade) => {
    const s = { id: uid(), name, grade, qrData:`IE-BSC|${uid()}|${encodeURIComponent(name)}`, present:false };
    setStudents(prev => [s, ...prev]);
  }

  const updateStudent = (id, updates) => {
    setStudents(prev => prev.map(s=> s.id===id ? {...s, ...updates}: s));
  }

  const deleteStudent = (id) => {
    if(!confirm('Eliminar estudiante?')) return;
    setStudents(prev => prev.filter(s=>s.id!==id));
  }

  const togglePresent = (id) => {
    setStudents(prev => prev.map(s=> s.id===id ? {...s, present: !s.present} : s));
  }

  const startScanner = async () => {
    if(scanning) return;
    try{
      const QRScanner = (await import('qr-scanner')).default;
      QRScanner.WORKER_PATH = 'https://unpkg.com/qr-scanner@1.4.2/qr-scanner-worker.min.js';
      if(videoRef.current){
        qrScannerRef.current = new QRScanner(videoRef.current, result => {
          handleScanResult(result);
        }, { highlightScanRegion: true, highlightCodeOutline: true });
        await qrScannerRef.current.start();
        setScanning(true);
      }
    }catch(e){
      console.error('No se pudo iniciar el scanner', e);
      alert('Error: no se pudo acceder al scanner. Asegúrate de usar HTTPS y otorgar permiso a la cámara. ' + e.message);
    }
  }

  const stopScanner = async () => {
    if(qrScannerRef.current){
      await qrScannerRef.current.stop();
      qrScannerRef.current.destroy();
      qrScannerRef.current = null;
    }
    setScanning(false);
  }

  const handleScanResult = (text) => {
    const parts = text.split('|');
    let idFromQR = null;
    if(parts.length>=2 && parts[0]=== 'IE-BSC'){
      idFromQR = parts[1];
    }
    let found = null;
    if(idFromQR) found = students.find(s=> s.id === idFromQR);
    if(!found){
      const nameEncoded = parts.slice(2).join('|');
      const nameDecoded = decodeURIComponent(nameEncoded || '');
      found = students.find(s=> s.name === nameDecoded);
    }
    if(found){
      updateStudent(found.id, { present: true });
      alert(`Asistencia registrada: ${found.name} (${found.grade})`);
    } else {
      alert('Código QR no reconocido en la base de datos. Asegúrate de que el QR provenga de esta aplicación.');
    }
  }

  const printQRCards = (selectedStudents) => {
    const w = window.open('', '_blank');
    const html = `
      <html>
      <head>
        <title>Imprimir QRs - IE Baldomero Sanín Cano</title>
        <style>
          @page { size: A4; margin: 10mm }
          body{ font-family: Arial, sans-serif; }
          .grid{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 10mm; }
          .card{ border:1px solid #ccc; padding:8mm; display:flex; flex-direction:column; align-items:center; justify-content:center; height:80mm }
          .qr{ margin-bottom:6mm }
          .name{ font-size:14px; font-weight:600 }
          .grade{ font-size:12px }
        </style>
      </head>
      <body>
        <h1>IE Baldomero Sanín Cano - QRs</h1>
        <div class="grid">
          ${selectedStudents.map(s => `
            <div class="card">
              <div class="qr"><img src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(s.qrData)}" alt="QR" /></div>
              <div class="name">${escapeHtml(s.name)}</div>
              <div class="grade">${escapeHtml(s.grade)}</div>
            </div>
          `).join('')}
        </div>
      <script>setTimeout(()=>window.print(),500)</script>
      </body>
      </html>
    `;
    w.document.write(html);
    w.document.close();
  }

  const escapeHtml = (s) => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

  const exportCSV = () => {
    const rows = [['id','name','grade','present']].concat(students.map(s=>[s.id,s.name,s.grade,s.present?1:0]));
    const csv = rows.map(r=> r.map(cell=> '"'+String(cell).replace(/"/g,'""')+'"').join(',')).join('\n');
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'estudiantes.csv'; a.click(); URL.revokeObjectURL(url);
  }

  const filtered = students.filter(s => s.name.toLowerCase().includes(query.toLowerCase()) || s.grade.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="min-h-screen p-4 bg-gray-50">
      <header className="bg-white shadow p-4 rounded mb-4 flex flex-col md:flex-row md:items-center md:justify-between">
        <h1 className="text-xl font-bold">Restaurante Escolar - IE Baldomero Sanín Cano</h1>
        <div className="mt-2 md:mt-0 text-sm text-gray-600">Total: {stats.total} • Presentes: {stats.present}</div>
      </header>

      <main className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <section className="md:col-span-1 bg-white p-4 rounded shadow">
          <h2 className="font-semibold mb-2">Administración</h2>
          <div className="mb-2">
            <label className="block text-sm">Buscar</label>
            <input value={query} onChange={e=>setQuery(e.target.value)} className="w-full border rounded px-2 py-1" placeholder="Buscar por nombre o grado" />
          </div>

          <div className="mb-2">
            <label className="block text-sm">Agregar estudiante</label>
            <AddStudentForm onAdd={(name,grade)=> addStudent(name,grade)} />
          </div>

          <div className="mb-2">
            <label className="block text-sm">Carga masiva CSV</label>
            <input type="file" accept="text/csv" onChange={e=> handleCSV(e.target.files[0])} />
            <small className="text-xs text-gray-500">CSV con encabezados: name (o nombre), grade (o grado)</small>
          </div>

          <div className="flex gap-2 mt-3">
            <button className="px-3 py-1 rounded bg-blue-600 text-white" onClick={()=> exportCSV()}>Exportar CSV</button>
            <button className="px-3 py-1 rounded bg-green-600 text-white" onClick={()=> printQRCards(students)}>Imprimir QRs</button>
          </div>

          <div className="mt-4">
            <h3 className="font-medium">Scanner</h3>
            <div className="mt-2">
              <div className="mb-2">
                <video ref={videoRef} style={{width:'100%', maxHeight:240, borderRadius:8, background:'#000'}} muted playsInline></video>
              </div>
              <div className="flex gap-2">
                {!scanning ? (
                  <button className="px-3 py-1 rounded bg-indigo-600 text-white" onClick={startScanner}>Iniciar Escáner</button>
                ) : (
                  <button className="px-3 py-1 rounded bg-red-600 text-white" onClick={stopScanner}>Detener Escáner</button>
                )}
                <button className="px-3 py-1 rounded bg-gray-200" onClick={()=>{ if(confirm('Resetear asistencia?')) setStudents(prev=> prev.map(s=>({...s, present:false}))) }}>Reset asistencia</button>
              </div>
              <small className="text-xs text-gray-500">Permite usar la cámara del móvil. Usa HTTPS o localhost.</small>
            </div>
          </div>

        </section>

        <section className="md:col-span-2 bg-white p-4 rounded shadow">
          <h2 className="font-semibold mb-2">Lista de estudiantes</h2>
          <div className="overflow-auto max-h-[60vh]">
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-gray-500">
                <tr><th>Nombre</th><th>Grado</th><th>QR</th><th>Asistencia</th><th>Acciones</th></tr>
              </thead>
              <tbody>
                {filtered.map(s=> (
                  <tr key={s.id} className="border-t">
                    <td className="py-2">{s.name}</td>
                    <td>{s.grade}</td>
                    <td>
                      <div style={{display:'flex', alignItems:'center', gap:8}}>
                        <div style={{width:64, height:64}}>
                          <QRCode value={s.qrData} size={64} renderAs="svg" />
                        </div>
                        <div className="text-xs">{s.id}</div>
                      </div>
                    </td>
                    <td>{s.present ? <span className="text-green-600">Presente</span> : <button className="text-sm underline" onClick={()=> togglePresent(s.id)}>Marcar</button>}</td>
                    <td>
                      <button className="mr-2 text-sm" onClick={()=>{ const newName = prompt('Editar nombre', s.name); if(newName!==null) updateStudent(s.id, {name:newName})}}>Editar</button>
                      <button className="mr-2 text-sm" onClick={()=> printQRCards([s])}>Imprimir</button>
                      <button className="text-sm text-red-600" onClick={()=> deleteStudent(s.id)}>Eliminar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4">
            <h3 className="font-medium">Dashboard</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
              <div className="p-3 border rounded">
                <div className="text-xs text-gray-500">Total estudiantes</div>
                <div className="text-lg font-bold">{stats.total}</div>
              </div>
              <div className="p-3 border rounded">
                <div className="text-xs text-gray-500">Presentes</div>
                <div className="text-lg font-bold">{stats.present}</div>
              </div>
              <div className="p-3 border rounded">
                <div className="text-xs text-gray-500">Ausentes</div>
                <div className="text-lg font-bold">{stats.total - stats.present}</div>
              </div>
              <div className="p-3 border rounded">
                <div className="text-xs text-gray-500">% Asistencia</div>
                <div className="text-lg font-bold">{stats.total? Math.round((stats.present/stats.total)*100):0}%</div>
              </div>
            </div>
          </div>

        </section>
      </main>

      <footer className="text-center text-xs text-gray-500 mt-6">App generada para IE Baldomero Sanín Cano — Responsive & PWA-ready</footer>
    </div>
  )
}

function AddStudentForm({onAdd}){
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('');
  return (
    <div>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Nombre" className="w-full border rounded px-2 py-1 mb-1" />
      <input value={grade} onChange={e=>setGrade(e.target.value)} placeholder="Grado" className="w-full border rounded px-2 py-1 mb-1" />
      <div className="flex gap-2">
        <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={()=>{ if(!name) return alert('Nombre requerido'); onAdd(name,grade); setName(''); setGrade(''); }}>Agregar</button>
      </div>
    </div>
  )
}
